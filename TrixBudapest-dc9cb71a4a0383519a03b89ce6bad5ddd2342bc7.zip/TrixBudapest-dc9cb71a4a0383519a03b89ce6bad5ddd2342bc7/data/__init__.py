# data/__init__.py

# This file makes the data directory a Python package
__all__ = [
    'games_data',
    'links_data', 
    'user_data'
]
